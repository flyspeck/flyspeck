/* -*- C -*-
 * $Id: ocamlbotwrapper.c.in,v 1.4 2007/06/29 21:43:21 rjones Exp $
 * SUID wrapper around ocaml program.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/resource.h>

const char *new_environ[] = {
  "PATH=/usr/bin",
  NULL
};

int
main ()
{
  struct rlimit lim;

  /* Don't worry about races here because we're just checking that
   * the installation looks reasonable.
   *
   * Die if the init script does not exist. */
  if (access ("init", R_OK) == -1) {
    perror ("init");
    exit (1);
  }

  /* Die if the ocaml program does not exist. */
  if (access ("/usr/bin/ocaml", R_OK|X_OK) == -1) {
    perror ("/usr/bin/ocaml");
    exit (1);
  }

  /* Die if the chroot directory does not exist. */
  if (access ("/var/local/xavierbot/chroot", R_OK|X_OK) == -1) {
    perror ("/var/local/xavierbot/chroot");
    exit (1);
  }

  /* Set some limits. */
#ifdef RLIMIT_AS
  lim.rlim_cur = lim.rlim_max = 32 * 1024 * 1024; /* bytes!?! */
  setrlimit (RLIMIT_AS, &lim);
#endif
#ifdef RLIMIT_CORE
  lim.rlim_cur = lim.rlim_max = 0;
  setrlimit (RLIMIT_CORE, &lim);
#endif
#ifdef RLIMIT_CPU
  lim.rlim_cur = lim.rlim_max = 10; /* seconds */
  setrlimit (RLIMIT_CPU, &lim);
#endif
#ifdef RLIMIT_MEMLOCK
  lim.rlim_cur = lim.rlim_max = 0;
  setrlimit (RLIMIT_MEMLOCK, &lim);
#endif
#ifdef RLIMIT_MSGQUEUE
  lim.rlim_cur = lim.rlim_max = 0;
  setrlimit (RLIMIT_MSGQUEUE, &lim);
#endif
#ifdef RLIMIT_NOFILE
  lim.rlim_cur = lim.rlim_max = 10;
  setrlimit (RLIMIT_NOFILE, &lim);
#endif
#ifdef RLIMIT_NPROC
  lim.rlim_cur = lim.rlim_max = 2;
  setrlimit (RLIMIT_NPROC, &lim);
#endif
#ifdef RLIMIT_SIGPENDING
  lim.rlim_cur = lim.rlim_max = 5;
  setrlimit (RLIMIT_SIGPENDING, &lim);
#endif
#ifdef RLIMIT_STACK
  lim.rlim_cur = lim.rlim_max = 8 * 1024 * 1024; /* bytes */
  setrlimit (RLIMIT_STACK, &lim);
#endif

  /* Run the ocaml program with the correct args. */
  execle ("/usr/bin/ocaml", "@OCAML@",
	  "-init", "init",
	  "-noprompt",
	  NULL, new_environ);

  /* If it failed, die with an error message. */
  perror ("/usr/bin/ocaml");
  exit (1);
}
