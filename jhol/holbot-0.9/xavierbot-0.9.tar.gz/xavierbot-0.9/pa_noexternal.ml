(* Delete the "external" word from the language.
 * $Id: pa_noexternal.ml,v 1.1 2007/06/28 19:47:26 rjones Exp $
 *)

open Printf
open Camlp4.PreCast
open Syntax

(*DELETE_RULE Gram
  str_item: "external"; LIDENT; ":"; ctyp; "="; LIST0 [ STRING ]
END;;*)

(* DELETE_RULE above didn't work.  Easier just to overwrite the rule. *)
EXTEND Gram
  GLOBAL: str_item;

  str_item: LEVEL "top" [
    [ "external"; LIDENT; ":"; ctyp; "="; LIST0 [ STRING ] ->
	<:str_item< print_endline "'external' keyword disabled" >> ]
  ];
END;;
