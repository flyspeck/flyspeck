A tool for formal verification of nonlinear inequalities in HOL Light.

Part of the Flyspeck project:
http://code.google.com/p/flyspeck/

Distributed under MIT License.

See docs/FormalVerifier.pdf for additional information.